package carrental;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CarReservationRepository extends PagingAndSortingRepository<CarReservation, Long>{


}