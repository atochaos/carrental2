package carrental2;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="CarManagement_table")
public class CarManagement {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private String carNo;
    private Long rentalAmt;
    private String carRegDt;
    private String carDelDt;
    private String procStatus;

    @PostUpdate
    public void onPostUpdate(){
        CarDeleted carDeleted = new CarDeleted();
        BeanUtils.copyProperties(this, carDeleted);
        carDeleted.publishAfterCommit();


        CarUpdated carUpdated = new CarUpdated();
        BeanUtils.copyProperties(this, carUpdated);
        carUpdated.publishAfterCommit();


    }

    @PrePersist
    public void onPrePersist(){
        CarRegistered carRegistered = new CarRegistered();
        BeanUtils.copyProperties(this, carRegistered);
        carRegistered.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }
    public Long getRentalAmt() {
        return rentalAmt;
    }

    public void setRentalAmt(Long rentalAmt) {
        this.rentalAmt = rentalAmt;
    }
    public String getCarRegDt() {
        return carRegDt;
    }

    public void setCarRegDt(String carRegDt) {
        this.carRegDt = carRegDt;
    }
    public String getCarDelDt() {
        return carDelDt;
    }

    public void setCarDelDt(String carDelDt) {
        this.carDelDt = carDelDt;
    }
    public String getProcStatus() {
        return procStatus;
    }

    public void setProcStatus(String procStatus) {
        this.procStatus = procStatus;
    }




}
