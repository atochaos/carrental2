package carrental2;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CarRentalRepository extends PagingAndSortingRepository<CarRental, Long>{


}